% Code for "Fuzzified Contrast Enhancement for Nearly Invisible Images"

% Degree of fuzzification   m=2;   
% Number of clusters        c=3;

For execution of code please see the Example_code.m file  


%Cite as   
"Fuzzified Contrast Enhancement for Nearly Invisible Images"
 IEEE Transactions on Circuits and Systems for Video Technology, 
 vol. 32, no. 5, pp. 2802-2813, May 2022

OR

R. Kumar and A. K. Bhandari, "Fuzzified Contrast Enhancement for Nearly Invisible Images," 
in IEEE Transactions on Circuits and Systems for Video Technology, vol. 32, no. 5, pp. 2802-2813,
May 2022, doi: 10.1109/TCSVT.2021.3098763.